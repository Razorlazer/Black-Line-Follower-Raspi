import RPi.GPIO as IO
import time
from motor import tesla_motor
from ultrasonic import ultrasonic
tesla  = tesla_motor(18,25,24,23)
ultra  = ultrasonic(20,21)
IO.setwarnings(False)
IO.setmode(IO.BCM)

left_IR = 8
right_IR = 7

IO.setup(left_IR, IO.IN)  # GPIO 2 -> Left IR out
IO.setup(right_IR, IO.IN)  # GPIO 3 -> Right IR out

def move(counter):
    if(IO.input(left_IR)==True and IO.input(right_IR)==True): #both while move forward 
         print("black is detected")
         if(counter == 3):
            
             print("stop")
             tesla.allStop()
             
         else:
             tesla.forwardDrive(10, 0.4)
             counter+=1
             print('counter')
             print(counter)
             time.sleep(0.2)
             
    elif(IO.input(left_IR) == True and IO.input(right_IR)==False):
        tesla.allStop()
        
        tesla.onlyRight(0.8)
        time.sleep(0.01)
        tesla.allStop()
        print('left')
    elif(IO.input(left_IR) == False and IO.input(right_IR)== True):
        tesla.allStop()
   
        tesla.onlyLeft(0.8)
        time.sleep(0.01)
        tesla.allStop()
        #tesla.forwardTurnRight()
        
        print('right')
    else:
         tesla.forwardDrive(0.1, 0.3)
         #time.sleep(0.02)
         time.sleep(0.01)
         print('forward')
     


counter = 0
while True:
    if(ultra.distance() < 10):
        print('object detected')
        tesla.allStop()
    else:
        move(counter)
      
  

