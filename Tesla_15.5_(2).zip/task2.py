import RPi.GPIO as IO
import time

IO.setwarnings(False)
IO.setmode(IO.BCM)

left_IR = 8
right_IR = 7
motor1 = 18
motor2 = 23
motor3 = 24
motor4 = 25

IO.setup(left_IR, IO.IN)  # GPIO 2 -> Left IR out
IO.setup(right_IR, IO.IN)  # GPIO 3 -> Right IR out

IO.setup(motor1, IO.OUT)  # GPIO 4 -> Motor 1 terminal A
IO.setup(motor2, IO.OUT)  # GPIO 14 -> Motor 1 terminal B

IO.setup(motor3, IO.OUT)  # GPIO 17 -> Motor Left terminal A
IO.setup(motor4, IO.OUT)  # GPIO 18 -> Motor Left terminal B


def stop_motors():
    IO.output(motor4, False)
    IO.output(motor2, False)
    IO.output(motor1, False)
    IO.output(motor3, False)


def go_forward():
    IO.output(motor1, False)
    IO.output(motor2, True)
    IO.output(motor4, True)
    IO.output(motor3, False)

counter = 0
 
while True:
     
     if(IO.input(left_IR)==True and IO.input(right_IR)==True): #both while move forward 
         print("black is detected")    
         if(counter == 2):
            
             print("stop")
             stop_motors()
             break
         else:
             go_forward()
             counter+=1
             print(counter)
             time.sleep(0.1)
             
     else:
        go_forward()
      
  