import time

import RPi.GPIO as GPIO

sensor1 = 16
sensor2 = 12
motor1 = 18
motor2 = 23
motor3 = 24
motor4 = 25

GPIO.setmode(GPIO.BCM)
GPIO.setup(sensor1, GPIO.IN)
GPIO.setup(sensor2, GPIO.IN)
GPIO.setup(motor1, GPIO.OUT)
GPIO.setup(motor2, GPIO.OUT)
GPIO.setup(motor3, GPIO.OUT)
GPIO.setup(motor4, GPIO.OUT)

GPIO.output(motor1, False)
GPIO.output(motor2, False)
GPIO.output(motor3, False)
GPIO.output(motor4, False)
print("IR Sensor Ready")
print(" ")


def go_forward():
    GPIO.output(motor1, False)
    GPIO.output(motor2, True)
    GPIO.output(motor4, True)
    GPIO.output(motor3, False)


def turn_right():
     GPIO.output(18, False)
     GPIO.output(23, True)
     GPIO.output(24, True) 
     GPIO.output(25, True)
     time.sleep(0.8)

def turn_left():
    GPIO.output(motor1, True)
    GPIO.output(motor2, True)
    GPIO.output(motor3, False)
    GPIO.output(motor4, True)
    time.sleep(0.8)



def go_backward():
    GPIO.output(motor1, True)
    GPIO.output(motor3, True)


def stop_motors():
    GPIO.output(motor4, False)
    GPIO.output(motor2, False)
    GPIO.output(motor1, False)
    GPIO.output(motor3, False)


try:

    while True:
        if GPIO.input(sensor1):
            # call motor function here
            stop_motors()
            turn_right()
            go_forward()
            print("Object Detected left")
            while GPIO.input(sensor1):
                time.sleep(0.2)
   
        else: 
            if GPIO.input(sensor2):
                # call motor function here
                stop_motors()
                turn_left()
                go_forward()
                print("Object Detected right")
                while GPIO.input(sensor2):
                    time.sleep(0.2)

except KeyboardInterrupt:
    GPIO.cleanup()
